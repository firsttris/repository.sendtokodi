import requests
import struct
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from xml.etree.ElementTree import ElementTree, Element, SubElement
from threading import Thread, Lock
# One request at a time blocked Kodi's MIME probe behind us (7.8 s before
# 'Creating InputStream' measured on a H618 box): serve each request in its
# own thread.
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import time
from time import monotonic
from uuid import uuid4


# Doubles as the manifest refresh delay: after this many seconds without a
# request, a request on a cached manifest re-resolves it with fresh stream urls.
# The local server itself stays up for the whole Kodi session and stops when
# Kodi requests an abort.
DASH_HTTPD_IDLE_TIMEOUT_SECONDS = 120

# Bounded LRU of served manifests; the least recently used one is evicted.
_MANIFEST_CACHE_SIZE = 20

_HTTPD_STATE_LOCK = Lock()
_HTTPD = None
_HTTPD_THREAD = None
_MANIFESTS = {}
_LATEST_MANIFEST_ID = None
_RANGE_REQUEST_TIMEOUT_SECONDS = 20
# YouTube answers freshly generated googlevideo URLs with a short soft block
# (HTTP 403); the range probe waits these seconds before each retry.
_RANGE_FETCH_RETRY_DELAYS = (3, 6)
# The init/index boxes usually sit in the first few KiB; grow the probe until found.
_RANGE_PROBE_INITIAL_BYTES = 4096
_RANGE_PROBE_MAX_BYTES = 256 * 1024
_RANGE_PROBE_MAX_WORKERS = 8
# yt-dlp reports AAC-in-MP4 audio as ext "m4a", which is not a valid DASH mimeType;
# InputStream Adaptive only accepts mp4, webm and x-matroska containers.
_AUDIO_MIME_TYPES = {
    'm4a': 'audio/mp4',
    'mp4': 'audio/mp4',
    'webm': 'audio/webm',
}

def _webm_decode_int(byte):
    # Returns size and value
    if byte >= 128:
        return 1, byte & 0b1111111
    elif byte >= 64:
        return 2, byte & 0b111111
    elif byte >= 32:
        return 3, byte & 0b11111
    elif byte >= 16:
        return 4, byte & 0b1111
    elif byte >= 8:
        return 5, byte & 0b111
    elif byte >= 4:
        return 6, byte & 0b11
    elif byte >= 2:
        return 7, byte & 0b1
    return 8, 0

def _webm_find_init_and_index_ranges(r):
    # Walk over the stream and find the offset of the 'Cues' element
    # This isn't so easy due to the EBML encoding
    init_range = (0,0)
    index_range = (0,0)

    # Verify the EMBL signature / root element
    signature = struct.unpack('>I', r.content[0:4])[0]
    if signature != 0x1A45DFA3:
        return init_range, index_range

    offset = 5
    while offset < len(r.content) - 16:
        # Get the element ID
        id_len, _ = _webm_decode_int(r.content[offset])
        id = int.from_bytes(r.content[offset:offset+id_len], byteorder='big', signed=False)

        # Get the size of the element
        size_len, sz = _webm_decode_int(r.content[offset+id_len])
        size_bytes = bytearray() + sz.to_bytes(1, 'big')
        begin = offset + id_len + 1
        end = offset + id_len + size_len
        size_bytes += r.content[begin:end]
        size = int.from_bytes(size_bytes, byteorder='big', signed=False)

        # Check if we have found the 'Cues' element we are looking for
        if id == 0x1C53BB6B:
            init_range = (0, offset - 1)
            index_range = (offset, offset + id_len + size_len + size - 1)
            break

        # Check if we have found the Matroska Segment, which is of unknown size,
        # and advance through the stream to the next element
        if id == 0x18538067:
            offset += id_len + size_len
        else:
            offset += id_len + size_len + size

    return init_range, index_range

def _mp4_find_init_and_index_ranges(r):
    # Walk over the stream and find the offset of the sidx box
    # Fortunately this is much easier than webm
    init_range = (0,0)
    index_range = (0,0)
    offset = 0
    while offset < len(r.content) - 8:
        box_size = struct.unpack('>I', r.content[offset:offset + 4])[0]
        box_type = struct.unpack('4s', r.content[offset + 4:offset + 8])[0]
        if box_size == 1:
            # 64-bit "largesize" follows the box type.
            if offset + 16 > len(r.content):
                break
            box_size = struct.unpack('>Q', r.content[offset + 8:offset + 16])[0]
        elif box_size == 0:
            # Box extends to the end of the file, so no sidx can follow it.
            if box_type != b"sidx":
                break
            box_size = len(r.content) - offset
        if box_size < 8:
            break
        if box_type == b"sidx":
            init_range = (0, offset - 1)
            index_range = (offset, offset + box_size - 1)
            break
        offset = offset + box_size
    return init_range, index_range

class _Prefix():
    def __init__(self, content):
        self.content = content


def _fetch_range(url, start, end):
    """Fetch bytes start..end of url; returns (data, offset of data in the file).

    A server that ignores the Range header answers 200 with the file from byte 0,
    so the offset is 0 then and the data covers 0..end.

    A 403 is retried after the _RANGE_FETCH_RETRY_DELAYS backoff, so YouTube's
    short soft block on fresh URLs does not fail the whole manifest build.
    """
    retry_delays = list(_RANGE_FETCH_RETRY_DELAYS)
    while True:
        # stream=True so a server that ignores the Range header does not make us
        # download the whole media file.
        r = requests.get(
            url,
            headers={'Range': 'bytes={}-{}'.format(start, end)},
            timeout=_RANGE_REQUEST_TIMEOUT_SECONDS,
            stream=True,
        )
        try:
            status = getattr(r, 'status_code', None)
            if status != 403 or not retry_delays:
                r.raise_for_status()
                offset = start if start == 0 or status == 206 else 0
                size = end + 1 - offset
                data = bytearray()
                for chunk in r.iter_content(chunk_size=16384):
                    data += chunk
                    if len(data) >= size:
                        break
                return bytes(data[:size]), offset
        finally:
            r.close()
        time.sleep(retry_delays.pop(0))


def _fetch_prefix(url, size):
    return _fetch_range(url, 0, size - 1)[0]


def find_init_and_index_ranges(url, container):
    if container == 'webm_dash':
        find_ranges = _webm_find_init_and_index_ranges
    else:
        find_ranges = _mp4_find_init_and_index_ranges

    data = b''
    size = _RANGE_PROBE_INITIAL_BYTES
    while True:
        # Only fetch what is missing; the bytes already probed are kept.
        chunk, offset = _fetch_range(url, len(data), size - 1)
        data = data[:offset] + chunk
        init_range, index_range = find_ranges(_Prefix(data))
        if index_range != (0, 0):
            return init_range, index_range
        if len(data) < size or size >= _RANGE_PROBE_MAX_BYTES:
            raise RuntimeError(
                "No segment index found in the first {} bytes of the {} stream".format(len(data), container)
            )
        size = min(size * 4, _RANGE_PROBE_MAX_BYTES)

def _iso8601_duration(secs):
    # yt-dlp may report no duration (None) and callers default to the string "0".
    if not isinstance(secs, (int, float)):
        try:
            secs = float(secs)
        except (TypeError, ValueError):
            secs = 0
    m, s = divmod(secs, 60)
    h, m = divmod(m, 60)
    d, h = divmod(h, 24)
    return "P{}DT{}H{}M{}S".format(int(d), int(h), int(m), s)

def transform_url(url):
    return url


def _dash_language_code(language):
    # yt-dlp reports e.g. "de-DE" or "en-desc"; Kodi maps the primary subtag to a language name.
    if not isinstance(language, str):
        return None
    primary = language.strip().split('-', 1)[0].lower()
    if not primary or primary in ('und', 'none'):
        return None
    return primary


def _is_descriptive_audio(language):
    return isinstance(language, str) and 'desc' in language.lower().split('-')[1:]


def _is_original_audio(format):
    # yt-dlp: language_preference 10 marks the language the video is actually in.
    try:
        return float(format.get('language_preference')) >= 10
    except (TypeError, ValueError):
        return False


class Manifest():
    def __init__(self, duration):
        self.mpd = Element('MPD')
        self.mpd.set('xmlns', 'urn:mpeg:DASH:schema:MPD:2011')
        self.mpd.set('profiles', 'urn:mpeg:dash:profile:isoff-main:2011')
        self.mpd.set('type', 'static')
        self.mpd.set('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance')
        self.mpd.set('xsi:schemaLocation', 'urn:mpeg:DASH:schema:MPD:2011 DASH-MPD.xsd')
        self.mpd.set('minBufferTime', _iso8601_duration(1.5))
        self.mpd.set('mediaPresentationDuration', _iso8601_duration(duration))

        self.period = SubElement(self.mpd, 'Period')

        self.audio_set = SubElement(self.period, 'AdaptationSet')
        self.audio_set.set('id', '0')
        self.audio_set.set('subsegmentAlignment', 'true')
        self.audio_set.set('contentType', 'audio')

        self.audio_set_role = SubElement(self.audio_set, 'Role')
        self.audio_set_role.set('schemeIdUri', 'urn:mpeg:DASH:role:2011')
        self.audio_set_role.set('value', 'main')

        self.video_set = SubElement(self.period, 'AdaptationSet')
        self.video_set.set('id', '1')
        self.video_set.set('subsegmentAlignment', 'true')
        self.video_set.set('contentType', 'video')

        self.video_set_role = SubElement(self.video_set, 'Role')
        self.video_set_role.set('schemeIdUri', 'urn:mpeg:DASH:role:2011')
        self.video_set_role.set('value', 'main')

        self.tree = ElementTree(self.mpd)

        self._audio_sets = {}
        self._prefetched_ranges = {}

    def prefetch_ranges(self, formats):
        # Probe all streams concurrently; add_*_format then reuses the results.
        urls = {}
        for format in formats:
            url = format.get('url')
            if url and url not in self._prefetched_ranges:
                urls[url] = format.get('container')
        if not urls:
            return

        def probe(item):
            url, container = item
            try:
                return url, find_init_and_index_ranges(url, container)
            except Exception as exc:
                return url, exc

        with ThreadPoolExecutor(max_workers=min(len(urls), _RANGE_PROBE_MAX_WORKERS)) as executor:
            for url, ranges in executor.map(probe, urls.items()):
                self._prefetched_ranges[url] = ranges

    def _find_init_and_index_ranges(self, url, container):
        ranges = self._prefetched_ranges.pop(url, None)
        if ranges is None:
            return find_init_and_index_ranges(url, container)
        if isinstance(ranges, Exception):
            raise ranges
        return ranges

    def _audio_set_for(self, format):
        language = format.get('language')
        audio_set = self._audio_sets.get(language)
        if audio_set is not None:
            return audio_set

        if not self._audio_sets:
            # The first language added becomes the default track.
            audio_set = self.audio_set
            self.audio_set.set('default', 'true')
        else:
            audio_set = Element('AdaptationSet')
            # Keep audio sets together and ahead of the video set; id 1 belongs to video.
            self.period.insert(len(self._audio_sets), audio_set)
            audio_set.set('id', str(len(self._audio_sets) + 1))
            audio_set.set('subsegmentAlignment', 'true')
            audio_set.set('contentType', 'audio')
            role = SubElement(audio_set, 'Role')
            role.set('schemeIdUri', 'urn:mpeg:DASH:role:2011')
            role.set('value', 'description' if _is_descriptive_audio(language) else 'dub')

        language_code = _dash_language_code(language)
        if language_code is not None:
            audio_set.set('lang', language_code)
        if _is_original_audio(format):
            audio_set.set('original', 'true')
        if _is_descriptive_audio(language):
            audio_set.set('impaired', 'true')

        self._audio_sets[language] = audio_set
        return audio_set

    def add_audio_format(self, format):
        url = format['url']
        # Resolve ranges first so a failing format leaves no partial Representation behind.
        init_range, idx_range = self._find_init_and_index_ranges(url, format['container'])

        rep = SubElement(self._audio_set_for(format), 'Representation')
        # Keep the full format_id: dubbed tracks share the itag (251-0, 251-1, ...) and ids must be unique.
        rep.set('id', str(format['format_id']))
        rep.set('codecs', format['acodec'])
        rep.set('audioSamplingRate', str(format['asr']))
        rep.set('startWithSAP', '1')
        rep.set('mimeType', _AUDIO_MIME_TYPES.get(format['ext'], "audio/{}".format(format['ext'])))
        kbps = format.get('tbr', format.get('abr'))
        if kbps is not None:
            rep.set('bandwidth', str(int(kbps * 1000)))

        channels = SubElement(rep, 'AudioChannelConfiguration')
        channels.set('schemeIdUri', 'urn:mpeg:dash:23003:3:audio_channel_configuration:2011')
        channels.set('value', str(format['audio_channels']))

        base_url = SubElement(rep, 'BaseURL')
        base_url.text = url

        segment_base = SubElement(rep, 'SegmentBase')
        segment_base.set('indexRange', '{}-{}'.format(idx_range[0], idx_range[1]))

        init = SubElement(segment_base, 'Initialization')
        init.set('range', '{}-{}'.format(init_range[0], init_range[1]))

    def add_video_format(self, format):
        url = format['url']
        # Resolve ranges first so a failing format leaves no partial Representation behind.
        init_range, idx_range = self._find_init_and_index_ranges(url, format['container'])
        width, height = str(format['resolution']).split('x', 1)

        rep = SubElement(self.video_set, 'Representation')
        rep.set('id', str(format['format_id']))
        rep.set('codecs', format['vcodec'])
        rep.set('startWithSAP', '1')
        rep.set('maxPlayoutRate', '1')
        rep.set('frameRate', str(format['fps']))
        rep.set('width', width)
        rep.set('height', height)
        rep.set('mimeType', "video/{}".format(format['ext']))
        kbps = format.get('tbr', format.get('vbr'))
        if kbps is not None:
            rep.set('bandwidth', str(int(kbps * 1000)))

        base_url = SubElement(rep, 'BaseURL')
        base_url.text = url

        segment_base = SubElement(rep, 'SegmentBase')
        segment_base.set('indexRange', '{}-{}'.format(idx_range[0], idx_range[1]))

        init = SubElement(segment_base, 'Initialization')
        init.set('range', '{}-{}'.format(init_range[0], init_range[1]))

    def emit(self):
        try:
            from xml.etree.ElementTree import indent
            indent(self.tree)
        except Exception:
            pass
        f = BytesIO()
        self.tree.write(f, encoding='utf-8', xml_declaration=True)
        #self.tree.write('manifest.mpd', encoding='utf-8', xml_declaration=True)
        return f.getvalue()


class HttpHandler(BaseHTTPRequestHandler):
    def log_message(self, _format, *_args):
        # BaseHTTPRequestHandler writes to stderr by default, which Kodi surfaces
        # as error <general>. Suppress noisy per-request logs for local manifest
        # serving to avoid false error reports during normal playback.
        return

    def _resolve_manifest_payload(self):
        # Preserve compatibility for direct handler tests where mpd is set on self.
        local_manifest = getattr(self, 'mpd', None)
        if local_manifest is not None:
            return bytes(local_manifest)

        path = self.path.split('?', 1)[0]
        if path == '/manifest.mpd':
            with _HTTPD_STATE_LOCK:
                manifest_id = _LATEST_MANIFEST_ID
        elif path.startswith('/manifest/') and path.endswith('.mpd'):
            manifest_id = path[len('/manifest/'):-len('.mpd')]
        else:
            manifest_id = None

        if not manifest_id:
            return None

        with _HTTPD_STATE_LOCK:
            entry = _MANIFESTS.get(manifest_id)
            if entry is None:
                return None
            refresh_manifest = entry.get('refresh_manifest')
            refreshed_at = entry.get('refreshed_at', 0)

        now = monotonic()
        refreshed_payload = None
        should_refresh = (
            refresh_manifest is not None
            and now - refreshed_at >= DASH_HTTPD_IDLE_TIMEOUT_SECONDS
        )
        if should_refresh:
            try:
                refreshed = refresh_manifest()
            except Exception:
                refreshed = None
            if refreshed is not None:
                refreshed_payload = bytes(refreshed)

        with _HTTPD_STATE_LOCK:
            entry = _MANIFESTS.get(manifest_id)
            if entry is None:
                return None

            if refreshed_payload is not None:
                entry['manifest'] = refreshed_payload
                entry['refreshed_at'] = now

            entry['last_access_at'] = now
            return entry['manifest']

    def do_HEAD(self):
        payload = HttpHandler._resolve_manifest_payload(self)
        if payload is None:
            self.send_response(404, 'Not Found')
            self.end_headers()
            return

        self.send_response(200, 'OK')
        self.send_header('Content-type', 'application/dash+xml')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()

    def do_GET(self):
        payload = HttpHandler._resolve_manifest_payload(self)
        if payload is None:
            self.send_response(404, 'Not Found')
            self.end_headers()
            return

        self.send_response(200, 'OK')
        self.send_header('Content-type', 'application/dash+xml')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


def _abort_requested_factory():
    """Return a callable that reports whether Kodi is shutting the add-on down.

    Outside Kodi (tests, no xbmc module or no Monitor) it always returns False.
    """
    try:
        import xbmc
        monitor = xbmc.Monitor()
    except Exception:
        return lambda: False
    return monitor.abortRequested


def _handle_request(httpd):
    # The server lives for the Kodi session (reuselanguageinvoker keeps the
    # module state between calls), so old localhost manifest urls handed to
    # Kodi keep working. handle_request returns every httpd.timeout seconds, so
    # the loop notices when Kodi requests an abort and the add-on can unload
    # without a thread stuck in a blocking accept.
    abort_requested = _abort_requested_factory()
    try:
        while not abort_requested():
            httpd.handle_request()
    finally:
        _stop_httpd(httpd)


def _stop_httpd(httpd):
    global _HTTPD, _HTTPD_THREAD, _LATEST_MANIFEST_ID
    with _HTTPD_STATE_LOCK:
        # A newer server may have replaced this one; never reset its state.
        if _HTTPD is httpd:
            _HTTPD = None
            _HTTPD_THREAD = None
            _LATEST_MANIFEST_ID = None
            _MANIFESTS.clear()
    try:
        httpd.server_close()
    except Exception:
        pass


def _ensure_httpd_started_locked():
    global _HTTPD, _HTTPD_THREAD
    if _HTTPD is not None:
        return _HTTPD

    server_address = ('127.0.0.1', 0)
    httpd = ThreadingHTTPServer(server_address, HttpHandler)
    # Return from handle_request every second so the serving loop can check
    # for a Kodi abort; there is no idle shutdown.
    httpd.timeout = 1
    httpd.handle_timeout = lambda: None

    thread = Thread(target=_handle_request, args=(httpd,))
    thread.daemon = True
    thread.start()

    _HTTPD = httpd
    _HTTPD_THREAD = thread
    return _HTTPD


def _register_manifest_locked(manifest, refresh_manifest=None):
    global _LATEST_MANIFEST_ID
    manifest_id = uuid4().hex
    now = monotonic()
    # Bounded cache: evict the least recently used manifest. Eviction only
    # removes the entry; it never closes the server.
    while len(_MANIFESTS) >= _MANIFEST_CACHE_SIZE:
        lru_id = min(_MANIFESTS, key=lambda key: _MANIFESTS[key].get('last_access_at', 0))
        del _MANIFESTS[lru_id]
    entry = {
        'manifest': bytes(manifest),
        'refresh_manifest': refresh_manifest,
        'refreshed_at': now,
        'last_access_at': now,
    }
    _MANIFESTS[manifest_id] = entry
    _LATEST_MANIFEST_ID = manifest_id
    return manifest_id


def start_httpd(manifest, refresh_manifest=None):
    # Start and register atomically so the eviction cannot race the registration.
    with _HTTPD_STATE_LOCK:
        httpd = _ensure_httpd_started_locked()
        manifest_id = _register_manifest_locked(manifest, refresh_manifest=refresh_manifest)
    return "http://127.0.0.1:{}/manifest/{}.mpd".format(httpd.server_port, manifest_id)


def _reset_httpd_state_for_tests():
    global _HTTPD, _HTTPD_THREAD, _MANIFESTS, _LATEST_MANIFEST_ID
    with _HTTPD_STATE_LOCK:
        _HTTPD = None
        _HTTPD_THREAD = None
        _MANIFESTS = {}
        _LATEST_MANIFEST_ID = None
