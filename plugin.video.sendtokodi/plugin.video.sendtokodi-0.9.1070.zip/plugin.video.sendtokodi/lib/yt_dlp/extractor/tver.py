import datetime as dt

from .streaks import StreaksBaseIE
from ..utils import (
    ExtractorError,
    GeoRestrictedError,
    clean_html,
    int_or_none,
    join_nonempty,
    make_archive_id,
    smuggle_url,
    str_or_none,
    strip_or_none,
    time_seconds,
    unified_timestamp,
    update_url_query,
    url_or_none,
)
from ..utils.traversal import require, traverse_obj


class TVerIE(StreaksBaseIE):
    _VALID_URL = r'https?://(?:www\.)?tver\.jp/(?:(?P<type>lp|corner|series|episodes?|feature)/)+(?P<id>[a-zA-Z0-9]+)'
    _GEO_COUNTRIES = ['JP']
    _GEO_BYPASS = False
    _TESTS = [{
        # via Streaks backend
        'url': 'https://tver.jp/episodes/epc1hdugbk',
        'info_dict': {
            'id': 'epc1hdugbk',
            'ext': 'mp4',
            'display_id': 'ref:baeebeac-a2a6-4dbf-9eb3-c40d59b40068',
            'title': '神回だけ見せます！ #2 壮烈！車大騎馬戦（木曜スペシャル）',
            'alt_title': '神回だけ見せます！ #2 壮烈！車大騎馬戦（木曜スペシャル） 日テレ',
            'description': 'md5:2726f742d5e3886edeaf72fb6d740fef',
            'uploader_id': 'tver-ntv',
            'channel': '日テレ',
            'duration': 1158.024,
            'thumbnail': 'https://statics.tver.jp/images/content/thumbnail/episode/xlarge/epc1hdugbk.jpg?v=16',
            'series': '神回だけ見せます！',
            'episode': '#2 壮烈！車大騎馬戦（木曜スペシャル）',
            'episode_number': 2,
            'timestamp': 1736486036,
            'upload_date': '20250110',
            'modified_timestamp': 1736870264,
            'modified_date': '20250114',
            'live_status': 'not_live',
            'release_timestamp': 1651453200,
            'release_date': '20220502',
            '_old_archive_ids': ['brightcovenew ref:baeebeac-a2a6-4dbf-9eb3-c40d59b40068'],
            'series_id': 'sru35hwdd2',
            'season_id': 'ss2lcn4af6',
        },
    }, {
        # via Brightcove backend (deprecated)
        'url': 'https://tver.jp/episodes/epc1hdugbk',
        'info_dict': {
            'id': 'ref:baeebeac-a2a6-4dbf-9eb3-c40d59b40068',
            'ext': 'mp4',
            'title': '神回だけ見せます！ #2 壮烈！車大騎馬戦（木曜スペシャル）',
            'alt_title': '神回だけ見せます！ #2 壮烈！車大騎馬戦（木曜スペシャル） 日テレ',
            'description': 'md5:2726f742d5e3886edeaf72fb6d740fef',
            'uploader_id': '4394098882001',
            'channel': '日テレ',
            'duration': 1158.101,
            'thumbnail': 'https://statics.tver.jp/images/content/thumbnail/episode/xlarge/epc1hdugbk.jpg?v=16',
            'tags': [],
            'series': '神回だけ見せます！',
            'episode': '#2 壮烈！車大騎馬戦（木曜スペシャル）',
            'episode_number': 2,
            'timestamp': 1651388531,
            'upload_date': '20220501',
            'release_timestamp': 1651453200,
            'release_date': '20220502',
            'series_id': 'sru35hwdd2',
            'season_id': 'ss2lcn4af6',
        },
        'params': {'extractor_args': {'tver': {'backend': ['brightcove']}}},
    }, {
        'url': 'https://tver.jp/corner/f0103888',
        'only_matching': True,
    }, {
        'url': 'https://tver.jp/lp/f0033031',
        'only_matching': True,
    }, {
        'url': 'https://tver.jp/series/srtxft431v',
        'info_dict': {
            'id': 'srtxft431v',
            'title': '名探偵コナン',
        },
        'playlist_mincount': 21,
    }, {
        'url': 'https://tver.jp/series/sru35hwdd2',
        'info_dict': {
            'id': 'sru35hwdd2',
            'title': '神回だけ見せます！',
        },
        'playlist_count': 11,
    }, {
        'url': 'https://tver.jp/series/srkq2shp9d',
        'only_matching': True,
    }]
    BRIGHTCOVE_URL_TEMPLATE = 'http://players.brightcove.net/%s/default_default/index.html?videoId=%s'
    _HEADERS = {
        'x-tver-platform-type': 'web',
        'Origin': 'https://tver.jp',
        'Referer': 'https://tver.jp/',
    }
    _PLATFORM_QUERY = {}
    _STREAKS_API_INFO = {}

    def _real_initialize(self):
        session_info = self._download_json(
            'https://platform-api.tver.jp/v2/api/platform_users/browser/create',
            None, 'Creating session', data=b'device_type=pc')
        self._PLATFORM_QUERY = traverse_obj(session_info, ('result', {
            'platform_uid': 'platform_uid',
            'platform_token': 'platform_token',
        }))
        self._STREAKS_API_INFO = self._download_json(
            'https://player.tver.jp/player/streaks_info_v2.json', None,
            'Downloading STREAKS API info', 'Unable to download STREAKS API info')

    def _call_platform_api(self, path, video_id, note=None, fatal=True, query=None):
        return self._download_json(
            f'https://platform-api.tver.jp/service/api/{path}', video_id, note,
            fatal=fatal, headers=self._HEADERS, query={
                **self._PLATFORM_QUERY,
                **(query or {}),
            })

    def _yield_episode_ids_for_series(self, series_id):
        seasons_info = self._download_json(
            f'https://service-api.tver.jp/api/v1/callSeriesSeasons/{series_id}',
            series_id, 'Downloading seasons info', headers=self._HEADERS)
        for season_id in traverse_obj(
                seasons_info, ('result', 'contents', lambda _, v: v['type'] == 'season', 'content', 'id', {str})):
            episodes_info = self._call_platform_api(
                f'v1/callSeasonEpisodes/{season_id}', series_id, f'Downloading season {season_id} episodes info')
            yield from traverse_obj(episodes_info, (
                'result', 'contents', lambda _, v: v['type'] == 'episode', 'content', 'id', {str}))

    def _real_extract(self, url):
        video_id, video_type = self._match_valid_url(url).group('id', 'type')
        backend = self._configuration_arg('backend', ['streaks'])[0]
        if backend not in ('brightcove', 'streaks'):
            raise ExtractorError(f'Invalid backend value: {backend}', expected=True)

        if video_type == 'series':
            series_info = self._call_platform_api(
                f'v2/callSeries/{video_id}', video_id, 'Downloading series info')
            return self.playlist_from_matches(
                self._yield_episode_ids_for_series(video_id), video_id,
                traverse_obj(series_info, ('result', 'content', 'content', 'title', {str})),
                ie=TVerIE, getter=lambda x: f'https://tver.jp/episodes/{x}')

        if video_type != 'episodes':
            webpage = self._download_webpage(url, video_id, note='Resolving to new URL')
            video_id = self._match_id(self._search_regex(
                (r'canonical"\s*href="(https?://tver\.jp/[^"]+)"', r'&link=(https?://tver\.jp/[^?&]+)[?&]'),
                webpage, 'url regex'))

        episode_info = self._call_platform_api(
            f'v1/callEpisode/{video_id}', video_id, 'Downloading episode info', fatal=False, query={
                'require_data': 'mylist,later[epefy106ur],good[epefy106ur],resume[epefy106ur]',
            })
        episode_content = traverse_obj(
            episode_info, ('result', 'episode', 'content')) or {}

        version = traverse_obj(episode_content, ('version', {str_or_none}), default='5')
        video_info = self._download_json(
            f'https://statics.tver.jp/content/episode/{video_id}.json', video_id, 'Downloading video info',
            query={'v': version}, headers={'Referer': 'https://tver.jp/'})

        episode = strip_or_none(episode_content.get('title'))
        series = str_or_none(episode_content.get('seriesTitle'))
        title = (
            join_nonempty(series, episode, delim=' ')
            or str_or_none(video_info.get('title')))
        provider = str_or_none(episode_content.get('productionProviderName'))
        onair_label = str_or_none(episode_content.get('broadcastDateLabel'))

        thumbnails = [
            {
                'id': quality,
                'url': update_url_query(
                    f'https://statics.tver.jp/images/content/thumbnail/episode/{quality}/{video_id}.jpg',
                    {'v': version}),
                'width': width,
                'height': height,
            }
            for quality, width, height in [
                ('small', 480, 270),
                ('medium', 640, 360),
                ('large', 960, 540),
                ('xlarge', 1280, 720),
            ]
        ]

        metadata = {
            'title': title,
            'series': series,
            'episode': episode,
            # an another title which is considered "full title" for some viewers
            'alt_title': join_nonempty(title, provider, onair_label, delim=' '),
            'channel': provider,
            'thumbnails': thumbnails,
            **traverse_obj(video_info, {
                'description': ('description', {str}),
                'release_timestamp': ('viewStatus', 'startAt', {int_or_none}),
                'episode_number': ('no', {int_or_none}),
                'series_id': ('seriesID', {str}),
                'season_id': ('seasonID', {str}),
            }),
        }

        brightcove_id = traverse_obj(video_info, ('video', ('videoRefID', 'videoID'), {str}, any))
        if brightcove_id and not brightcove_id.isdecimal():
            brightcove_id = f'ref:{brightcove_id}'

        streaks_id = traverse_obj(video_info, ('streaks', 'videoRefID', {str}))
        if streaks_id and not streaks_id.startswith('ref:'):
            streaks_id = f'ref:{streaks_id}'

        # Deprecated Brightcove extraction reachable w/extractor-arg or fallback; errors are expected
        if backend == 'brightcove' or not streaks_id:
            if backend != 'brightcove':
                self.report_warning(
                    'No STREAKS ID found; falling back to Brightcove extraction', video_id=video_id)
            if not brightcove_id:
                raise ExtractorError('Unable to extract brightcove reference ID', expected=True)
            account_id = traverse_obj(video_info, (
                'video', 'accountID', {str}, {require('brightcove account ID', expected=True)}))
            return {
                **metadata,
                '_type': 'url_transparent',
                'url': smuggle_url(
                    self.BRIGHTCOVE_URL_TEMPLATE % (account_id, brightcove_id),
                    {'geo_countries': self._GEO_COUNTRIES}),
                'ie_key': 'BrightcoveNew',
            }

        project_id = video_info['streaks']['projectID']
        key_idx = dt.datetime.fromtimestamp(time_seconds(hours=9), dt.timezone.utc).month % 6 or 6

        try:
            streaks_info = self._extract_from_streaks_api(project_id, streaks_id, {
                'Origin': 'https://tver.jp',
                'Referer': 'https://tver.jp/',
                'X-Streaks-Api-Key': self._STREAKS_API_INFO[project_id]['api_key'][f'key0{key_idx}'],
            })
        except GeoRestrictedError as e:
            # Catch and re-raise with metadata_available to support --ignore-no-formats-error
            self.raise_geo_restricted(e.orig_msg, countries=self._GEO_COUNTRIES, metadata_available=True)
            streaks_info = {}

        return {
            **streaks_info,
            **metadata,
            'id': video_id,
            '_old_archive_ids': [make_archive_id('BrightcoveNew', brightcove_id)] if brightcove_id else None,
        }


class TVerOlympicIE(StreaksBaseIE):
    IE_NAME = 'tver:olympic'

    _API_BASE = 'https://olympic-data.tver.jp/api'
    _VALID_URL = r'https?://(?:www\.)?tver\.jp/olympic/milanocortina2026/(?P<type>live|video)/play/(?P<id>\w+)'
    _TESTS = [{
        'url': 'https://tver.jp/olympic/milanocortina2026/video/play/3b1d4462150b42558d9cc8aabb5238d0/',
        'info_dict': {
            'id': '3b1d4462150b42558d9cc8aabb5238d0',
            'ext': 'mp4',
            'title': '【開会式】ぎゅっと凝縮ハイライト',
            'display_id': 'ref:3b1d4462150b42558d9cc8aabb5238d0',
            'duration': 712.045,
            'live_status': 'not_live',
            'modified_date': r're:\d{8}',
            'modified_timestamp': int,
            'tags': 'count:1',
            'thumbnail': r're:https://.+\.(?:jpg|png)',
            'timestamp': 1770420187,
            'upload_date': '20260206',
            'uploader_id': 'tver-olympic',
        },
    }, {
        'url': 'https://tver.jp/olympic/milanocortina2026/live/play/glts313itwvj/',
        'info_dict': {
            'id': 'glts313itwvj',
            'ext': 'mp4',
            'title': '開会式ハイライト',
            'channel_id': 'ntv',
            'display_id': 'ref:sp_260207_spc_01_dvr',
            'duration': 7680,
            'live_status': 'was_live',
            'modified_date': r're:\d{8}',
            'modified_timestamp': int,
            'thumbnail': r're:https://.+\.(?:jpg|png)',
            'timestamp': 1770420300,
            'upload_date': '20260206',
            'uploader_id': 'tver-olympic-live',
        },
    }]

    def _real_extract(self, url):
        video_type, video_id = self._match_valid_url(url).group('type', 'id')
        live_from_start = self.get_param('live_from_start')

        if video_type == 'live':
            project_id = 'tver-olympic-live'
            api_key = 'a35ebb1ca7d443758dc7fcc5d99b1f72'
            olympic_data = traverse_obj(self._download_json(
                f'{self._API_BASE}/live/{video_id}', video_id), ('contents', 'live', {dict}))
            media_id = traverse_obj(olympic_data, ('video_id', {str}))

            now = time_seconds()
            start_timestamp_str = traverse_obj(olympic_data, ('onair_start_date', {str}))
            start_timestamp = unified_timestamp(start_timestamp_str, tz_offset=9)
            if not start_timestamp:
                raise ExtractorError('Unable to extract on-air start time')
            end_timestamp = traverse_obj(olympic_data, (
                'onair_end_date', {unified_timestamp(tz_offset=9)}, {require('on-air end time')}))

            if now < start_timestamp:
                self.raise_no_formats(
                    f'This program is scheduled to start at {start_timestamp_str} JST', expected=True)

                return {
                    'id': video_id,
                    'live_status': 'is_upcoming',
                    'release_timestamp': start_timestamp,
                }
            elif start_timestamp <= now < end_timestamp:
                live_status = 'is_live'
                if live_from_start:
                    media_id += '_dvr'
            elif end_timestamp <= now:
                dvr_end_timestamp = traverse_obj(olympic_data, (
                    'dvr_end_date', {unified_timestamp(tz_offset=9)}))
                if dvr_end_timestamp and now < dvr_end_timestamp:
                    live_status = 'was_live'
                    media_id += '_dvr'
                else:
                    raise ExtractorError(
                        'This program is no longer available', expected=True)
        else:
            project_id = 'tver-olympic'
            api_key = '4b55a4db3cce4ad38df6dd8543e3e46a'
            media_id = video_id
            live_status = 'not_live'
            olympic_data = traverse_obj(self._download_json(
                f'{self._API_BASE}/video/{video_id}', video_id), ('contents', 'video', {dict}))

        return {
            **self._extract_from_streaks_api(project_id, f'ref:{media_id}', {
                'Origin': 'https://tver.jp',
                'Referer': 'https://tver.jp/',
                'X-Streaks-Api-Key': api_key,
            }, live_from_start=live_from_start),
            **traverse_obj(olympic_data, {
                'title': ('title', {clean_html}, filter),
                'alt_title': ('sub_title', {clean_html}, filter),
                'channel': ('channel', {clean_html}, filter),
                'channel_id': ('channel_id', {clean_html}, filter),
                'description': (('description', 'description_l', 'description_s'), {clean_html}, filter, any),
                'timestamp': ('onair_start_date', {unified_timestamp(tz_offset=9)}),
                'thumbnail': (('picture_l_url', 'picture_m_url', 'picture_s_url'), {url_or_none}, any),
            }),
            'id': video_id,
            'live_status': live_status,
        }
