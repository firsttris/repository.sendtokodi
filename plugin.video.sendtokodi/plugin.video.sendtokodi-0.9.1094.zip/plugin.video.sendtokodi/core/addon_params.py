import json
import os
import platform
import urllib.parse


DEFAULT_MEDIA_DOWNLOAD_PATH = 'special://profile/addon_data/plugin.video.sendtokodi/downloads'
DEFAULT_YTDLP_VERSION = 'latest'
DEFAULT_DENO_VERSION = 'latest'
DEFAULT_JS_RUNTIME_MODE = 'auto'
DEFAULT_DASH_HTTPD_IDLE_TIMEOUT_SECONDS = 120
MIN_DASH_HTTPD_IDLE_TIMEOUT_SECONDS = 10
MAX_DASH_HTTPD_IDLE_TIMEOUT_SECONDS = 600
YT_DLP_OPTIONS_QUERY_PARAM = 'yt-dlp-options'
LEGACY_YDL_OPTS_QUERY_PARAM = 'ydlOpts'


def _parse_ydl_opts_json(raw_value):
    if not raw_value:
        return {}

    parsed = json.loads(raw_value)
    if not isinstance(parsed, dict):
        raise ValueError('yt-dlp options must be a JSON object')
    return parsed


def _resolve_ydl_opts_from_query_params(parsed_query):
    ydl_options_raw = parsed_query.get(YT_DLP_OPTIONS_QUERY_PARAM, [None])[0]
    if ydl_options_raw is None:
        ydl_options_raw = parsed_query.get(LEGACY_YDL_OPTS_QUERY_PARAM, [None])[0]
    return _parse_ydl_opts_json(ydl_options_raw)


def parse_cli_paramstring(paramstring):
    parsed_query = parse_query_params(paramstring)
    query_url = parsed_query.get('url', [None])[0]
    if query_url:
        return {
            'url': query_url,
            'ydlOpts': _resolve_ydl_opts_from_query_params(parsed_query),
        }

    additional_params_index = paramstring.find(' ')
    if additional_params_index == -1:
        return {'url': paramstring[1:], 'ydlOpts': {}}

    additional_params = json.loads(paramstring[additional_params_index:])
    return {
        'url': paramstring[1:additional_params_index],
        'ydlOpts': additional_params['ydlOpts'],
    }


def parse_query_params(paramstring):
    if not paramstring or not paramstring.startswith("?"):
        return {}

    query_part = paramstring[1:]
    if " " in query_part:
        query_part = query_part.split(" ", 1)[0]
    return urllib.parse.parse_qs(query_part)


def resolve_queue_request(paramstring):
    parsed = parse_query_params(paramstring)
    action = parsed.get("action", [None])[0]
    if action not in ("queue", "q"):
        return None

    target_url = parsed.get("url", [None])[0]
    if not target_url:
        return None

    return {
        "url": target_url,
        "title": parsed.get("title", parsed.get("name", [None]))[0],
    }


def build_flat_playlist_item_url(plugin_url, video_url, paramstring):
    parsed_query = parse_query_params(paramstring)
    if parsed_query.get('url', [None])[0]:
        query_items = [('url', video_url)]

        ydl_options_raw = parsed_query.get(YT_DLP_OPTIONS_QUERY_PARAM, [None])[0]
        ydl_options_param = YT_DLP_OPTIONS_QUERY_PARAM
        if ydl_options_raw is None:
            ydl_options_raw = parsed_query.get(LEGACY_YDL_OPTS_QUERY_PARAM, [None])[0]
            ydl_options_param = LEGACY_YDL_OPTS_QUERY_PARAM
        if ydl_options_raw is not None:
            query_items.append((ydl_options_param, ydl_options_raw))

        return plugin_url + '?' + urllib.parse.urlencode(query_items)

    list_item_url = plugin_url + "?" + video_url
    additional_params_index = paramstring.find(' ')
    if additional_params_index != -1:
        list_item_url = list_item_url + " " + paramstring[additional_params_index:]
    return list_item_url


def resolve_playlist_item_title(video):
    if 'title' in video:
        return video['title']
    return video['url']


def build_ydl_opts(parsed_params, deno_opts=None):
    ydl_opts = {'extract_flat': 'in_playlist'}
    ydl_opts.update(parsed_params.get('ydlOpts', {}))
    if deno_opts:
        ydl_opts.update(deno_opts)
    return ydl_opts


def resolve_deno_opts(handle, get_setting, get_deno_ydl_opts):
    auto_update = get_setting(handle, "deno_autodownload") == 'true'
    requested_version = DEFAULT_DENO_VERSION
    return get_deno_ydl_opts(auto_download=auto_update, requested_version=requested_version)


def _normalize_js_runtime_mode(mode):
    value = (mode or '').strip().lower()
    if value in ('auto', 'deno', 'quickjs', 'disabled'):
        return value
    return DEFAULT_JS_RUNTIME_MODE


def _is_armv7_machine(get_machine):
    try:
        machine = (get_machine() or '').strip().lower()
    except Exception:
        machine = ''

    # Common names include armv7l and armv7hl.
    return machine.startswith('armv7')


def resolve_quickjs_opts(
    handle,
    get_setting,
    path_exists=os.path.exists,
    is_executable=os.access,
    access_flag=os.X_OK,
):
    quickjs_path = (get_setting(handle, 'quickjs_path') or '').strip()
    if not quickjs_path:
        return {}
    if not path_exists(quickjs_path):
        return {}
    if not is_executable(quickjs_path, access_flag):
        return {}

    return {
        'js_runtimes': {'quickjs': {'path': quickjs_path}},
        'remote_components': {'ejs:github'},
    }


def resolve_js_runtime_opts(
    handle,
    get_setting,
    get_deno_ydl_opts,
    get_machine=platform.machine,
    path_exists=os.path.exists,
    is_executable=os.access,
    access_flag=os.X_OK,
):
    runtime_mode = _normalize_js_runtime_mode(get_setting(handle, 'js_runtime_mode'))

    if runtime_mode == 'disabled':
        return {}

    if runtime_mode == 'deno':
        return resolve_deno_opts(handle, get_setting, get_deno_ydl_opts)

    quickjs_opts = resolve_quickjs_opts(
        handle,
        get_setting,
        path_exists=path_exists,
        is_executable=is_executable,
        access_flag=access_flag,
    )

    if runtime_mode == 'quickjs':
        return quickjs_opts

    if _is_armv7_machine(get_machine) and quickjs_opts:
        return quickjs_opts

    deno_opts = resolve_deno_opts(handle, get_setting, get_deno_ydl_opts)
    if deno_opts:
        return deno_opts
    return quickjs_opts


def resolve_deno_settings(handle, get_setting):
    enabled = get_setting(handle, "deno_enabled") == 'true'
    auto_update = get_setting(handle, "deno_autodownload") == 'true'
    return {
        'enabled': enabled,
        'auto_update': auto_update,
        'version': DEFAULT_DENO_VERSION,
    }


def resolve_media_download_settings(handle, get_setting):
    enabled = get_setting(handle, "media_autodownload") == 'true'
    custom_path = get_setting(handle, "media_download_path")
    return {
        'enabled': enabled,
        'path': custom_path or DEFAULT_MEDIA_DOWNLOAD_PATH,
    }


def resolve_ytdlp_settings(handle, get_setting):
    auto_update = get_setting(handle, "ytdlp_autodownload") == 'true'
    return {
        'auto_update': auto_update,
        'version': DEFAULT_YTDLP_VERSION,
    }


def resolve_dash_httpd_idle_timeout(handle, get_setting):
    raw_value = (get_setting(handle, "dash_httpd_idle_timeout") or '').strip()
    if not raw_value:
        return DEFAULT_DASH_HTTPD_IDLE_TIMEOUT_SECONDS

    try:
        timeout_seconds = int(raw_value)
    except (TypeError, ValueError):
        return DEFAULT_DASH_HTTPD_IDLE_TIMEOUT_SECONDS

    if timeout_seconds < MIN_DASH_HTTPD_IDLE_TIMEOUT_SECONDS:
        return MIN_DASH_HTTPD_IDLE_TIMEOUT_SECONDS
    if timeout_seconds > MAX_DASH_HTTPD_IDLE_TIMEOUT_SECONDS:
        return MAX_DASH_HTTPD_IDLE_TIMEOUT_SECONDS
    return timeout_seconds
